import os
import pymysql
import google.generativeai as genai
from datetime import datetime, timedelta
from flask import Flask, request, render_template, redirect, url_for, flash, session, jsonify
from functools import wraps

app = Flask(__name__)
app.secret_key = "super_secret_spaghetti_key"

# --- CONFIGURATION ---
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '', 
    'db': 'student_concerns',
    'port': 3307,
    'cursorclass': pymysql.cursors.DictCursor
}

# --- AI CONFIGURATION (Gemini 3 Flash) ---
GEMINI_API_KEY = "AIzaSyAeuGuimJHPPSF1_kGhLJh40KUzUvkBxVo"
genai.configure(api_key=GEMINI_API_KEY)

# Enhanced Instructions with Sentiment Analysis & Trigger Protocol
AI_SYSTEM_INSTRUCTIONS = """
You are the Student Concerns Assistant. Your goal is to resolve concerns using school policy.

POLICIES:
- ACADEMIC: Grade appeals must be filed within 7 days of posting. Contact the Registrar.
- FINANCIAL: Tuition installment deadlines are every 15th of the month. Contact the Bursar.
- WELFARE: Counseling is available 8am-5pm. Contact Student Affairs.

SMART ESCALATION LOGIC:
1. Detect Sentiment: If the student uses aggressive language, CAPS, or expresses extreme frustration (e.g., "I'm sick of this", "Fix it now"), they are classified as 'Upset'.
2. Trigger Protocol: If the student is 'Upset' or their problem is too complex for AI, you MUST include the hidden tag [TRIGGER_FORM] in your response.
3. Response Style: Be empathetic. If triggering the form, say: "I understand your frustration. I am escalating this to a priority human review. Please fill out the formal form that has just been highlighted on your screen."

FORMATTING RULES:
- Use bullet points (*) for lists.
- Use double asterisks (**) for key terms or departments.
- Use a new line for every new point.
"""

model = genai.GenerativeModel(
    model_name="gemini-3-flash-preview",
    system_instruction=AI_SYSTEM_INSTRUCTIONS
)

# --- ACCESS CONTROL DECORATOR ---
def login_required(role=None):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'user_role' not in session:
                return redirect(url_for('login_page'))
            if role and session.get('user_role') != role and session.get('user_role') != 'Admin':
                return redirect(url_for('login_page'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# --- DATABASE LOGIC ---
def get_db_connection():
    return pymysql.connect(**DB_CONFIG)

def log_event(concern_id, action):
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("INSERT INTO audit_log (concern_id, action) VALUES (%s, %s)", (concern_id, action))
        conn.commit()
    finally:
        conn.close()

def check_slas():
    conn = get_db_connection()
    now = datetime.now()
    try:
        with conn.cursor() as cursor:
            cursor.execute("UPDATE concerns SET is_escalated = TRUE WHERE status IN ('Submitted', 'Routed') AND created_at < %s", (now - timedelta(days=2)))
            cursor.execute("UPDATE concerns SET is_escalated = TRUE WHERE status = 'Read' AND last_updated < %s", (now - timedelta(days=5)))
        conn.commit()
    finally:
        conn.close()

# --- STUDENT & CHAT ROUTES ---
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/chat', methods=['POST'])
def chat_with_ai():
    try:
        data = request.get_json()
        if not data:
            return jsonify({"reply": "Error: No data received"}), 400
            
        user_message = data.get('message')

        # Generate content with Gemini
        chat_session = model.start_chat(history=[])
        response = chat_session.send_message(user_message)
        
        return jsonify({
            "reply": response.text,
            "status": "success"
        })

    except Exception as e:
        print(f"\n!!! GEMINI ERROR: {str(e)} !!!\n")
        return jsonify({"reply": f"Internal Error: {str(e)}"}), 200

@app.route('/submit', methods=['POST'])
def submit_concern():
    email = request.form.get('email')
    category = request.form.get('category')
    subject = request.form.get('subject')
    description = request.form.get('description')
    anonymous = 1 if request.form.get('anonymous') else 0
    
    routing = {'Academic': 'Registrar', 'Financial': 'Bursar', 'Welfare': 'Student Affairs'}
    dept = routing.get(category, 'General Admin')

    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                INSERT INTO concerns (student_email, category, department, subject, description, is_anonymous, status) 
                VALUES (%s, %s, %s, %s, %s, %s, 'Routed')
            """, (email, category, dept, subject, description, anonymous))
            concern_id = cursor.lastrowid
        conn.commit()
    finally:
        conn.close()

    log_event(concern_id, f"Concern routed to {dept}")
    flash("Concern submitted successfully!")
    return redirect(url_for('index'))

# --- DATA FETCHING HELPER ---
def fetch_dashboard_data(category=None):
    check_slas()
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            if category:
                cursor.execute("SELECT * FROM concerns WHERE category = %s ORDER BY created_at DESC", (category,))
                concerns = cursor.fetchall()
                cursor.execute("SELECT COUNT(*) as total, SUM(is_escalated) as escalated FROM concerns WHERE category = %s", (category,))
            else:
                cursor.execute("SELECT * FROM concerns ORDER BY created_at DESC")
                concerns = cursor.fetchall()
                cursor.execute("SELECT COUNT(*) as total, SUM(is_escalated) as escalated FROM concerns")
            
            stats = cursor.fetchone()
            cursor.execute("SELECT * FROM audit_log ORDER BY timestamp DESC LIMIT 15")
            logs = cursor.fetchall()
    finally:
        conn.close()
    
    total = stats['total'] if stats and stats['total'] else 0
    escalated = stats['escalated'] if stats and stats['escalated'] else 0
    esc_rate = (escalated / total * 100) if total > 0 else 0
    
    return concerns, total, esc_rate, logs

# --- PROTECTED ADMIN DASHBOARDS ---
@app.route('/admin')
@login_required('Admin')
def admin_dashboard():
    concerns, total, esc_rate, logs = fetch_dashboard_data()
    return render_template('admin.html', concerns=concerns, total=total, esc_rate=esc_rate, logs=logs, title="Master Portal")

@app.route('/academic')
@login_required('Academic')
def academic_dashboard():
    concerns, total, esc_rate, logs = fetch_dashboard_data('Academic')
    return render_template('admin.html', concerns=concerns, total=total, esc_rate=esc_rate, logs=logs, title="Registrar Portal")

@app.route('/financial')
@login_required('Financial')
def financial_dashboard():
    concerns, total, esc_rate, logs = fetch_dashboard_data('Financial')
    return render_template('admin.html', concerns=concerns, total=total, esc_rate=esc_rate, logs=logs, title="Bursar Portal")

@app.route('/welfare')
@login_required('Welfare')
def welfare_dashboard():
    concerns, total, esc_rate, logs = fetch_dashboard_data('Welfare')
    return render_template('admin.html', concerns=concerns, total=total, esc_rate=esc_rate, logs=logs, title="Welfare Portal")

# --- AUTH & ACTIONS ---
@app.route('/login')
def login_page():
    return render_template('login.html')

@app.route('/login_as/<role>')
def login_as(role):
    session['user_role'] = role
    dashboards = {'Admin': 'admin_dashboard', 'Academic': 'academic_dashboard', 'Financial': 'financial_dashboard', 'Welfare': 'welfare_dashboard'}
    return redirect(url_for(dashboards.get(role, 'login_page')))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login_page'))

@app.route('/update_status', methods=['POST'])
def update_status():
    cid = request.form.get('id')
    status = request.form.get('status')
    action = request.form.get('action_taken')
    
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("UPDATE concerns SET status = %s, action_taken = %s, last_updated = NOW() WHERE id = %s", (status, action, cid))
            if status == 'Resolved': 
                cursor.execute("UPDATE concerns SET is_escalated = FALSE WHERE id = %s", (cid,))
        conn.commit()
    finally:
        conn.close()
    
    log_event(cid, f"Status set to {status}")
    return redirect(request.referrer)

if __name__ == '__main__':
    app.run(debug=True, port=5000)